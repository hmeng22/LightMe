UseGDataXML

介绍如何使用GDataXML库来解析xml



