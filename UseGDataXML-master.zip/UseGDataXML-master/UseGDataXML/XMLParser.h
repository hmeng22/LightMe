//
//  XMLParser.h
//  UseGDataXML
//
//  Created by Uncle Fatty on 13-9-26.
//  Copyright (c) 2013年 QBins. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMLParser : NSObject

- (void)parser:(NSData *)xmlData;

@end
