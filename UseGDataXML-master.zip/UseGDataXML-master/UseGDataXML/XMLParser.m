//
//  XMLParser.m
//  UseGDataXML
//
//  Created by Uncle Fatty on 13-9-26.
//  Copyright (c) 2013年 QBins. All rights reserved.
//

#import "XMLParser.h"
#import "GDataXMLNode.h"

@implementation XMLParser

- (void)parser:(NSData *)xmlData
{
    if (xmlData != nil) {
        //装载xml data
        GDataXMLDocument *xmlDoc = [[GDataXMLDocument alloc] initWithData:xmlData options:0 error:nil];
        
        //获取根节点（menus）
        GDataXMLElement *rootElement = [xmlDoc rootElement];
      
        //获取item节点
        NSArray *menus = [rootElement elementsForName:@"item"];
       
        for (GDataXMLElement *item in menus) {
            GDataXMLElement *idElement = [[item elementsForName:@"id"] objectAtIndex:0];
            NSLog(@"id->%@",[idElement stringValue]);
            
            GDataXMLElement *nameElement = [[item elementsForName:@"name"] objectAtIndex:0];
            NSLog(@"name->%@",[nameElement stringValue]);
            
            GDataXMLElement *priceElement = [[item elementsForName:@"price"] objectAtIndex:0];
            NSLog(@"price->%@",[priceElement stringValue]);
            
            NSLog(@"------------------------------------------");
        }
        
    } else {
        NSLog(@"xml data is empty");
    }
}

@end
